<?php
require_once('web_produccion.php');
require_once('web_alistamiento.php');
require_once('web_conciliacion.php');
require_once('web_controlp.php');
require_once('web_controlt.php');
require_once('web_preparacion.php');
require_once('web_revision.php');