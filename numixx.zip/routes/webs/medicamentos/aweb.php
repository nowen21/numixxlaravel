<?php
//require_once('');
require_once('web_casa.php');
require_once('web_medicame.php');
require_once('web_minvima.php');
require_once('web_mlote.php');
require_once('web_mmarca.php');
require_once('web_mnpt.php');
