<?php
//require_once('');
require_once('web_dmedico.php');
 require_once('web_dmarca.php');

require_once('web_dlote.php');

