<?php
require_once('clinicas/web_clinica.php');
require_once('dmedico/aweb.php');
require_once('administracion/aweb.php');
require_once('medicamentos/aweb.php');

require_once('usuario/aweb.php');
require_once('reporte/aweb.php');
require_once('produccion/aweb.php');
require_once('reportes/web_modulo.php');
