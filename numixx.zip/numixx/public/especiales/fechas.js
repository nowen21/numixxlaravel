$(".d_diligencia").datepicker({
    dateFormat: "yy-mm-dd",
    changeMonth: true,
    changeYear: true,
    maxDate:'+0d',
    yearRange: "-70:+0",
    onSelect: function(dateText) {
    
    }
});