# numixxlaravel
Proyecto de administración de nutriones parentales para la empresas numixx S.A.S

04-02-2020

1 clinicas 

	* agregar opción seleccionar todos
	
2 clinica rango

	* las clinicas salgan en orden alfabético
	
	* seleccionar múltiple
	
3	rangos

	* adicionar codigo 
	
	* importar el excel
	
4 	tablas

	* crearlas responsive
	
5	reportes remisión

	* revisar error
	
6	formulación

	* velocidad de infusion = volumen total/tiempo de infusion. LISTO
	
	* mostar todo los medicamentos ofertados pero no dejar hacer descuento de inventario hasta no tenerlo