<div class="form-group row">
    <div class="form-group col-md-6">
        <?php echo e(Form::label('sis_clinica_id', 'Clínica:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::select('sis_clinica_id', $todoxxxx['clinicid'], $todoxxxx['modeloxx']->sis_clinica_id, ['class' => 'form-control-plaintext','id'=>'sis_clinica_id'])); ?>

        <?php else: ?>
        <?php echo e(Form::select('sis_clinica_id', $todoxxxx['clinicid'], null, ['class' => $errors->first('sis_clinica_id') ? 
    'form-control is-invalid select2' : 'form-control select2','id'=>'sis_clinica_id'])); ?>

        <?php endif; ?>
        <?php if($errors->has('sis_clinica_id')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('sis_clinica_id')); ?>

        </div>
        <?php endif; ?>
    </div>


    <div class="form-group col-md-6">
        <?php echo e(Form::label('name', 'Nombres:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('name', $todoxxxx['modeloxx']->name, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('name', null, ['class' => $errors->first('name') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'Nombres', 'maxlength' => '120', 'autofocus','style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('name')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('name')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="form-group col-md-6">
        <?php echo e(Form::label('email', 'E-mail:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('email', $todoxxxx['modeloxx']->email, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('email', null, ['class' => $errors->first('email') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'E-mail', 'maxlength' => '120', 'autofocus','style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('email')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('email')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-6">
        <?php echo e(Form::label('password', 'Contraseña:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::password('password',  ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::password('password', ['class' => $errors->first('password') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'Contraseña', 'maxlength' => '120', 'autofocus','style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('password')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('password')); ?>

        </div>
        <?php endif; ?>
    </div>



    <div class="form-group col-md-12">
        <?php echo e(Form::label('sis_esta_id', 'Estado:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::select('sis_esta_id', $todoxxxx['estadoxx'], $todoxxxx['modeloxx']->sis_esta_id, ['class' => 'form-control-plaintext','id'=>'sis_esta_id'])); ?>

        <?php else: ?>
        <?php echo e(Form::select('sis_esta_id', $todoxxxx['estadoxx'], null, ['class' => $errors->first('sis_esta_id') ? 
        'form-control is-invalid select2' : 'form-control select2','id'=>'sis_esta_id'])); ?>

        <?php endif; ?>
        <?php if($errors->has('sis_esta_id')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('sis_esta_id')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Sistema/Usuario/formulario/formulario.blade.php ENDPATH**/ ?>