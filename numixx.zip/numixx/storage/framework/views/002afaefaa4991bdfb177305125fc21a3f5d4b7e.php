<?php $__env->startSection('content'); ?>
  <div class="card text-left">
    <div class="card-header">
      <h1 style="text-align: center"><strong><?php echo e($todoxxxx["tituloxx"]); ?></strong> </h1>
    </div>
    <div class="card-body">
      <h5 class="card-title"></h5>
      <?php echo Form::model($todoxxxx['modeloxx']); ?>

        <?php echo $__env->make('layouts.components.botones.botones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
        <?php echo $__env->make($todoxxxx["rutacarp"].'formulario.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.components.botones.botones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
      <?php echo Form::close(); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Medicame/Casa/ver.blade.php ENDPATH**/ ?>