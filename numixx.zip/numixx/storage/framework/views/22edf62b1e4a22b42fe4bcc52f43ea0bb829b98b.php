<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-clipboard-check"></i>
        <p>
            Producción
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['alistami-leer'])): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('alistami')); ?>" class="nav-link">
                    <i class="fas fa-child nav-icon"></i>
                    <p>Alistamientos</p>
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['preparac-leer'])): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('preparac')); ?>" class="nav-link">
                    <i class="fas fa-child nav-icon"></i>
                    <p>Preparaciones</p>
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['controlp-leer'])): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('controlp')); ?>" class="nav-link">
                    <i class="fas fa-child nav-icon"></i>
                    <p>Control en proceso</p>
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['controlt-leer'])): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('controlt')); ?>" class="nav-link">
                    <i class="fas fa-child nav-icon"></i>
                    <p>Control productos terminados</p>
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['concilia-leer'])): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('concilia')); ?>" class="nav-link">
                    <i class="fas fa-child nav-icon"></i>
                    <p>Conciliaciones</p>
                </a>
            </li>
        <?php endif; ?>

    </ul>
</li>
<?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/layouts/menus/produccion.blade.php ENDPATH**/ ?>