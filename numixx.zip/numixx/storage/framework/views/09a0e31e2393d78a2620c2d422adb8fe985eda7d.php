<div class="form-group row">
    <div class="form-group col-md-4">
        <?php echo e(Form::label('registro', 'Fecha registro:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('registro', $todoxxxx['modeloxx']->registro, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('registro', null, ['class' => $errors->first('registro') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'Fecha registro', 'maxlength' => '120', 'style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('registro')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('registro')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="form-group col-md-4">
        <?php echo e(Form::label('cedula', 'Cédula:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('cedula', $todoxxxx['modeloxx']->cedula, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('cedula', null, ['class' => $errors->first('cedula') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'Cédula', 'maxlength' => '120', 'autofocus','style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('cedula')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('cedula')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="form-group col-md-4">
        <?php echo e(Form::label('nombres', 'Nombres:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('nombres', $todoxxxx['modeloxx']->nombres, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('nombres', null, ['class' => $errors->first('nombres') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'Nombres', 'maxlength' => '120', 'autofocus','style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('nombres')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('nombres')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('peso', 'Peso:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('peso', $todoxxxx['modeloxx']->peso, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('peso', null, ['class' => $errors->first('peso') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'Peso', 'maxlength' => '120', 'autofocus','style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('peso')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('peso')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('genero_id', 'Género:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::select('genero_id', $todoxxxx['generoxx'], $todoxxxx['modeloxx']->genero_id, ['class' => 'form-control-plaintext','id'=>'genero_id'])); ?>

        <?php else: ?>
        <?php echo e(Form::select('genero_id', $todoxxxx['generoxx'], null, ['class' => $errors->first('genero_id') ? 
        'form-control is-invalid select2' : 'form-control select2','id'=>'genero_id'])); ?>

        <?php endif; ?>
        <?php if($errors->has('genero_id')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('genero_id')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('ep_id', 'Eps:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::select('ep_id', $todoxxxx['epsxxxxx'], $todoxxxx['modeloxx']->ep_id, ['class' => 'form-control-plaintext','id'=>'ep_id'])); ?>

        <?php else: ?>
        <?php echo e(Form::select('ep_id', $todoxxxx['epsxxxxx'], null, ['class' => $errors->first('ep_id') ? 
        'form-control is-invalid select2' : 'form-control select2','id'=>'ep_id'])); ?>

        <?php endif; ?>
        <?php if($errors->has('ep_id')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('ep_id')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('npt_id', 'Npt:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::select('npt_id', $todoxxxx['nptxxxxx'], $todoxxxx['modeloxx']->npt_id, ['class' => 'form-control-plaintext','id'=>'npt_id'])); ?>

        <?php else: ?>
        <?php echo e(Form::select('npt_id', $todoxxxx['nptxxxxx'], null, ['class' => $errors->first('npt_id') ? 
        'form-control is-invalid select2' : 'form-control select2','id'=>'npt_id'])); ?>

        <?php endif; ?>
        <?php if($errors->has('npt_id')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('npt_id')); ?>

        </div>
        <?php endif; ?>
    </div>

    

    <div class="form-group col-md-4">
        <?php echo e(Form::label('cama', 'Cama:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('cama', $todoxxxx['modeloxx']->cama, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('cama', null, ['class' => $errors->first('cama') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'Cama', 'maxlength' => '120', 'autofocus','style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('cama')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('cama')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('servicio_id', 'Servicio:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::select('servicio_id', $todoxxxx['servicio'], $todoxxxx['modeloxx']->servicio_id, ['class' => 'form-control-plaintext','id'=>'servicio_id'])); ?>

        <?php else: ?>
        <?php echo e(Form::select('servicio_id', $todoxxxx['servicio'], null, ['class' => $errors->first('servicio_id') ? 
        'form-control is-invalid select2' : 'form-control select2','id'=>'servicio_id'])); ?>

        <?php endif; ?>
        <?php if($errors->has('servicio_id')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('servicio_id')); ?>

        </div>
        <?php endif; ?>
    </div>

    

    <div class="form-group col-md-4">
        <?php echo e(Form::label('fechnaci', 'Fecha de Nacimiento:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('fechnaci', $todoxxxx['modeloxx']->fechnaci, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('fechnaci', null, ['class' => $errors->first('fechnaci') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'Fecha de Nacimiento', 'maxlength' => '120', 'autofocus','style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('fechnaci')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('fechnaci')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('edad', 'Edad:', ['class' => 'control-label col-form-label-sm'])); ?>

        <div id="edad" class="form-control" style='height: 28px'></div>
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('departamento_id', 'Departamento:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::select('departamento_id', $todoxxxx['departam'], $todoxxxx['modeloxx']->departamento_id, ['class' => 'form-control-plaintext','id'=>'departamento_id'])); ?>

        <?php else: ?>
        <?php echo e(Form::select('departamento_id', $todoxxxx['departam'], null, ['class' => $errors->first('departamento_id') ? 
        'form-control is-invalid select2' : 'form-control select2','id'=>'departamento_id'])); ?>

        <?php endif; ?>
        <?php if($errors->has('departamento_id')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('departamento_id')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-6">
        <?php echo e(Form::label('municipio_id', 'Municipio:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::select('municipio_id', $todoxxxx['municipi'], $todoxxxx['modeloxx']->municipio_id, ['class' => 'form-control-plaintext','id'=>'municipio_id'])); ?>

        <?php else: ?>
        <?php echo e(Form::select('municipio_id', $todoxxxx['municipi'], null, ['class' => $errors->first('municipio_id') ? 
        'form-control is-invalid select2' : 'form-control select2','id'=>'municipio_id'])); ?>

        <?php endif; ?>
        <?php if($errors->has('municipio_id')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('municipio_id')); ?>

        </div>
        <?php endif; ?>
    </div>
    
    <div class="form-group col-md-6">
        <?php echo e(Form::label('sis_esta_id', 'Estado:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::select('sis_esta_id', $todoxxxx['estadoxx'], $todoxxxx['modeloxx']->sis_esta_id, ['class' => 'form-control-plaintext','id'=>'sis_esta_id'])); ?>

        <?php else: ?>
        <?php echo e(Form::select('sis_esta_id', $todoxxxx['estadoxx'], null, ['class' => $errors->first('sis_esta_id') ? 
        'form-control is-invalid select2' : 'form-control select2','id'=>'sis_esta_id'])); ?>

        <?php endif; ?>
        <?php if($errors->has('sis_esta_id')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('sis_esta_id')); ?>

        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Pacientes/Paciente/formulario/formulario.blade.php ENDPATH**/ ?>