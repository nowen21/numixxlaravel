
    <div class="text-center" style="width: 100%">
        <?php if($sis_esta_id == 1): ?>
        <span class="fas fa-check text-success" aria-hidden="true"></span>
        <?php else: ?>
        <span class="fas fa-times text-danger" aria-hidden="true"></span>
        <?php endif; ?>
        <?php echo e($s_estado); ?>

    </div><?php /**PATH D:\Instalados\wamp64\www\numixx\resources\views/layouts/components/botones/estadoxx.blade.php ENDPATH**/ ?>