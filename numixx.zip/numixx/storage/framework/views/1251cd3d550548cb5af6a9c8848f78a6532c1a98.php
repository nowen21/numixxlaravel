<footer class="main-footer">
  <strong>Derechos de Autor &copy; 2020 <a href="http://numixx.com//" target="blank">NUMIXX</a>.</strong> Todos los derechos reservados
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 1.0
  </div>
</footer><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/layouts/footer.blade.php ENDPATH**/ ?>