<ul class="navbar-nav ml-auto">
        <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item px-2">
                <a class="nav-link" href="<?php echo e(route('login')); ?>">Iniciar sesión</a>
            </li>
        <?php else: ?>
            <li class="nav-item dropdown px-2">
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        Salir
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        <?php endif; ?>
  <!-- Messages Dropdown Menu -->
  
  <!-- End Messages Dropdown Menu -->

  <!-- Notifications Dropdown Menu -->
  
  <!-- Notifications Dropdown Menu -->

  <!-- Controls -->
  
  <!-- End Controls -->
</ul><?php /**PATH D:\Instalados\wamp64\www\numixx\resources\views/layouts/nav-bar/right/index.blade.php ENDPATH**/ ?>