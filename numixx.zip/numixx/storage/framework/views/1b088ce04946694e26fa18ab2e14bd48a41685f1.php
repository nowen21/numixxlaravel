<script>
    $(function(){

    });
</script><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Dispositivos/Dinvima/js/tabla.blade.php ENDPATH**/ ?>