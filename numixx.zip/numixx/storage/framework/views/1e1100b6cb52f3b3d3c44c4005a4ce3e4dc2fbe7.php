<?php $__currentLoopData = $todoxxxx['tablasxx']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tablasxx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php $__env->startComponent('layouts.components.tablajquery.generalx', ['todoxxxx'=>$tablasxx]); ?>
    <?php $__env->slot('tableName'); ?>
    <?php echo e($tablasxx['tablaxxx']); ?>

    <?php $__env->endSlot(); ?>
    <?php $__env->slot('class'); ?>
    <?php $__env->endSlot(); ?> 
  <?php echo $__env->renderComponent(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\Instalados\wamp64\www\numixx\resources\views/layouts/components/pestanias/index.blade.php ENDPATH**/ ?>