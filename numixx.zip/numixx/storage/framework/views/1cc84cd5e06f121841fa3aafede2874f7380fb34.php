<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-clipboard-check"></i>
        <p>
            Dispositivos
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['dmedico-leer'])): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('dmedico')); ?>" class="nav-link">
                    <i class="fas fa-child nav-icon"></i>
                    <p>Médicos</p>
                </a>
            </li>
        <?php endif; ?>
    </ul>
</li>
<?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/layouts/menus/dispositivos.blade.php ENDPATH**/ ?>