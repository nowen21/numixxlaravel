<script>
  $(function(){
    $('.select2').select2({
      language: "es"
    });
    $("#name").keyup(function () {
      $(this).val($(this).val().toUpperCase())
    });
  });
</script><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Sistema/Usuario/Usuario/js/js.blade.php ENDPATH**/ ?>