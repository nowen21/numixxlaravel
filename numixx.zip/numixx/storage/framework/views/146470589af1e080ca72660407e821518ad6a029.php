<div class="card text-left">
  <div class="card-header">
    <h1 style="text-align: center"><strong><?php echo e($todoxxxx["tituloxx"]); ?></strong> </h1>
  </div>
  <div class="card-body">
    <h5 class="card-title"></h5>
    <form method = "POST" action= "<?php echo e(route($todoxxxx["routxxxx"].'.crear', $todoxxxx["parametr"])); ?>">
      <?php echo csrf_field(); ?>
      <?php echo $__env->make('layouts.components.botones.botones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
      <?php echo $__env->make($todoxxxx["rutacarp"].$todoxxxx["carpetax"].'.formulario.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('layouts.components.botones.botones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    <?php echo Form::close(); ?>

  </div>
</div><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Medicame/Medicamento/Mnpt/crear.blade.php ENDPATH**/ ?>