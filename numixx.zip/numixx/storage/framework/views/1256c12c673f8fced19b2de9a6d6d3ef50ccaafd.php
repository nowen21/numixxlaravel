<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-clipboard-check"></i>
        <p>
            Reportes
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['contropf-leer'])): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('controlpf')); ?>" class="nav-link">
                    <i class="fas fa-child nav-icon"></i>
                    <p>Controles en proceso y productos finalizados</p>
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['ordprodu-leer'])): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('orden')); ?>" class="nav-link">
                    <i class="fas fa-child nav-icon"></i>
                    <p>Órdenes de producción</p>
                </a>
            </li>
        <?php endif; ?>

    </ul>
</li>
<?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/layouts/menus/reportes.blade.php ENDPATH**/ ?>