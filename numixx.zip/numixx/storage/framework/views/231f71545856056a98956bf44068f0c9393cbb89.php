<div class="card">
  <div class="card-header">
    <?php echo e($todoxxxx['cardhead']); ?>

  </div>
  <div class="card-header p-2">
    <ul class="nav nav-tabs">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['roles-leer', 'roles-crear', 'roles-editar', 'roles-borrar'])): ?>
      <li class="nav-item"><a class="nav-link<?php echo e(($todoxxxx['slotxxxx']=='roles') ?' active' : ''); ?> text-sm" 
        href="<?php echo e(route('roles.editar', $todoxxxx['parametr'])); ?>">Roles</a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['rpermiso-leer', 'rpermiso-crear', 'rpermiso-editar', 'rpermiso-borrar'])): ?>
      <li class="nav-item"><a class="nav-link<?php echo e(($todoxxxx['slotxxxx']=='rpermiso') ?' active' : ''); ?> text-sm" 
        href="<?php echo e(route('rpermiso', $todoxxxx['parametr'])); ?>">Permisos</a></li>
      <?php endif; ?>
      
    </ul>
  </div>
  <div class="card-body">
    <div class="tab-content">
      <div class="tab-pane active" id="<?php echo e($todoxxxx['slotxxxx']); ?>">
        <?php if(isset($roles)): ?>
          <?php echo e($roles); ?>

        <?php endif; ?>
        <?php if(isset($rpermiso)): ?>
          <?php echo e($rpermiso); ?>

        <?php endif; ?>
       
      </div>
    </div>
  </div>
</div><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Sistema/Rol/tabsxxxx/tabsxxxx.blade.php ENDPATH**/ ?>