<script>
    $(function(){

    });
</script><?php /**PATH D:\Instalados\wamp64\www\numixx\resources\views/Medicame/Medicamento/Medicame/js/tabla.blade.php ENDPATH**/ ?>