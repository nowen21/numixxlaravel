<div class="card card-outline card-secondary">
    <style>
       .selected{
        background-color: coral;
       }
    </style>
    <div class="card-header">
        <h3 class="card-title">
            <?php echo e($todoxxxx['titulist']); ?>

            <?php if($todoxxxx['vercrear']): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($todoxxxx['permisox'].'-crear')): ?>
                    <a class="btn btn-sm btn-primary ml-2" title="<?php echo e($todoxxxx['titunuev']); ?>" href="<?php echo e(route($todoxxxx['routxxxx'].'.nuevo',$todoxxxx['parametr'])); ?>">  
                        <?php echo e($todoxxxx['titunuev']); ?>

                    </a>
                <?php endif; ?>
            <?php endif; ?>
        </h3>
    </div>
    <div class="card-body">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([$todoxxxx['permisox'].'-leer',$todoxxxx['permisox'].'-crear',$todoxxxx['permisox'].'-editar',$todoxxxx['permisox'].'-borrar'])): ?>
            <div class="table-responsive">
                <table id="<?php echo e($todoxxxx['tablaxxx']); ?>" class="table table-bordered   table-sm">
                    <thead>
                        <tr class="text-center">
                            <?php if($todoxxxx['accitabl']): ?>
                                <th width="150">Acciones</th> 
                            <?php endif; ?>
                           
                        
                            
                            <?php $__currentLoopData = $todoxxxx['cabecera']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cabecera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th> <?php echo e($cabecera['td']); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/layouts/components/tablajquery/generalx.blade.php ENDPATH**/ ?>