<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-12">
  <!-- Brand Logo -->
  <a href="<?php echo e(route('/')); ?>" class="brand-link">
    <img src="<?php echo e(asset('img/favicon.png')); ?>" alt="NUMIXX" class="brand-image img-circle elevation-3"
      style="opacity: .8">
    <span class="brand-text font-weight-light">NUMIXX</span>
  </a>
  <!-- Brand Logo -->

  <!-- Sidebar -->
  <?php if(auth()->guard()->check()): ?>
  <div class="sidebar">
    <!-- Sidebar user panel (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      
    <div class="info">
      <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?></a>
    </div>
  </div>

  <!-- Sidebar Menu -->
  <nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
      <!-- Add icons to the links using the .nav-icon class with font-awesome or any other icon font library -->


      <!-- ADMINISTRACION -->
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('administracion-modulo')): ?>
      <?php echo $__env->make('layouts.menus.administracion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('paciente-modulo')): ?>
      <?php echo $__env->make('layouts.menus.pacientes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('medicamento-modulo')): ?>
      <?php echo $__env->make('layouts.menus.medicamentos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dispositivo-modulo')): ?>
      <?php echo $__env->make('layouts.menus.dispositivos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produccion-modulo')): ?>
      <?php echo $__env->make('layouts.menus.produccion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reportes-modulo')): ?>
      <?php echo $__env->make('layouts.menus.reportes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sistema-modulo')): ?>
      <?php echo $__env->make('layouts.menus.sistema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>

      <!-- FIN TERRITORIO -->
      <!-- ACCIONES -->
      
      
      <!-- FIN ADMINISTRACION -->

      <!-- INDICADORES -->
      

      <!-- FIN INDICADORES -->
    </ul>
  </nav>
  <!-- /.sidebar-menu -->
  </div>
  <?php endif; ?>
  <!-- /.sidebar -->
</aside>
<?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/layouts/mainsidebar.blade.php ENDPATH**/ ?>