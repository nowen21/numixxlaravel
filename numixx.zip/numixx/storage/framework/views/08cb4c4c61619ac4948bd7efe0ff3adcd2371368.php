<?php $__env->startSection('content'); ?>
  <div class="jumbotron text-center">
  <h1 class="display-4">NUMIXX</h1>
  <p class="lead">FORMULACIONES</p>
  <hr class="my-4">
  <p>Sistema de Formulaciones</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Instalados\wamp64\www\numixx\resources\views/welcome.blade.php ENDPATH**/ ?>