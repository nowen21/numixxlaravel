<!-- jQuery -->
<script src="<?php echo e(asset('adminlte/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-confirm.min.js')); ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(asset('adminlte/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>

<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- ChartJS -->

<!-- Sparkline -->
<script src="<?php echo e(asset('adminlte/plugins/sparklines/sparkline.js')); ?>"></script>
<!-- JQVMap -->

<!-- jQuery Knob Chart -->

<!-- daterangepicker -->


<!-- Tempusdominus Bootstrap 4 -->

<!-- Summernote -->

<!-- overlayScrollbars -->

<!-- AdminLTE App -->
<script src="<?php echo e(asset('adminlte/dist/js/adminlte.js')); ?>"></script>


<script src="<?php echo e(asset('adminlte/dist/js/demo.js')); ?>"></script>

<!-- AdminLTE dashboard demo (This is only for demo purposes) -->

<!-- AdminLTE for demo purposes -->

<script src="<?php echo e(asset('adminlte/plugins/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/mask/jquery.mask.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/select2/js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/select2/js/i18n/es.js')); ?>"></script>
<script src="<?php echo e(asset('especiales/contarcaracteres.js')); ?>"></script>
<script src="<?php echo e(asset('especiales/fechas.js')); ?>"></script>
<script src="<?php echo e(asset('especiales/combos.js')); ?>"></script>
<?php echo $__env->make('layouts.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('scripts'); ?><?php /**PATH D:\Instalados\wamp64\www\numixx\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>