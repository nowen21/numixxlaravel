<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([$todoxxxx['permisox'].'-leer',$todoxxxx['permisox'].'-crear',$todoxxxx['permisox'].'-editar',$todoxxxx['permisox'].'-borrar'])): ?>
    <div class="table-responsive">
        <table id="<?php echo e($tableName); ?>" class="table table-bordered   table-sm">
            <thead>
                <tr class="text-center">
                    <th width="150">Acciones</th>
                    <?php $__currentLoopData = $todoxxxx['cabecera']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cabecera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                        <th> <?php echo e($cabecera['td']); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
        </table>
    </div>
<?php endif; ?>    <?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/layouts/components/tablajquery/bodyxxxx.blade.php ENDPATH**/ ?>