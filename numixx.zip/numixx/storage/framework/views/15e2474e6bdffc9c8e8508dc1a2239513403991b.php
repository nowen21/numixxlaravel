
<?php $__env->startComponent('layouts.components.pestanias.pestanias',['todoxxxx'=>$todoxxxx]); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Sistema/Usuario/pestanias.blade.php ENDPATH**/ ?>