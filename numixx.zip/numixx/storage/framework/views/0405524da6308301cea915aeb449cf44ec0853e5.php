    <div class="form-group col-md-4">
        <?php echo e(Form::label('sis_clinica_id', 'Clínica:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::select('sis_clinica_id', $todoxxxx['clinicax'], $todoxxxx['modeloxx']->sis_clinica_id, ['class' => 'form-control-plaintext','id'=>'sis_clinica_id'])); ?>

        <?php else: ?>
        <?php echo e(Form::select('sis_clinica_id', $todoxxxx['clinicax'], null, ['class' => $errors->first('sis_clinica_id') ? 
        'form-control is-invalid select2' : 'form-control select2','id'=>'sis_clinica_id'])); ?>

        <?php endif; ?>
        <?php if($errors->has('sis_clinica_id')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('sis_clinica_id')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="form-group col-md-4">
        <?php echo e(Form::label('tiempo', 'Tiempo Infusión:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('tiempo', $todoxxxx['modeloxx']->tiempo, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('tiempo', 24, ['class' => $errors->first('tiempo') ?
         'form-control  is-invalid calcularvolumen' : 'form-control calcularvolumen', 'placeholder' => 'Tiempo Infusión', 'maxlength' => '120', 'style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('tiempo')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('tiempo')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('velocidad', 'Velocidad Infusión:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('velocidad', $todoxxxx['modeloxx']->velocidad, ['class' => 'form-control-plaintext',
        'style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('velocidad', 64.7, ['class' => $errors->first('velocidad') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'Velocidad Infusión:', 
         'maxlength' => '120', 'autofocus','style'=>'height: 28px','readonly'])); ?>

        <?php endif; ?>
        <?php if($errors->has('velocidad')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('velocidad')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="form-group col-md-4">
        <?php echo e(Form::label('volumen', 'Volumen Total:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('volumen', $todoxxxx['modeloxx']->volumen, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('volumen', 1553, ['class' => $errors->first('volumen') ?
         'form-control  is-invalid calcularvolumen' : 'form-control calcularvolumen', 'placeholder' => 'Volumen Total', 'maxlength' => '120', 'autofocus','style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('volumen')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('volumen')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('purga', 'Purga:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('purga', $todoxxxx['modeloxx']->purga, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('purga', 30, ['class' => $errors->first('purga') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'Purga', 'maxlength' => '120', 'autofocus','style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('purga')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('purga')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-4">
        <?php echo e(Form::label('peso', 'Peso:', ['class' => 'control-label col-form-label-sm'])); ?>

        <?php if($todoxxxx['accionxx'] == 'Ver'): ?>
        <?php echo e(Form::text('peso', $todoxxxx['modeloxx']->peso, ['class' => 'form-control-plaintext','style'=>'height: 28px'])); ?>

        <?php else: ?>
        <?php echo e(Form::text('peso', 68, ['class' => $errors->first('peso') ?
         'form-control  is-invalid' : 'form-control', 'placeholder' => 'Peso', 'maxlength' => '120', 'autofocus','style'=>'height: 28px'])); ?>

        <?php endif; ?>
        <?php if($errors->has('peso')): ?>
        <div class="invalid-feedback d-block">
            <?php echo e($errors->first('peso')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group col-md-12">
        <hr style="border:  #000000 solid 2px" />
    </div>
    <?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Pacientes/Cformula/formulario/cabecera.blade.php ENDPATH**/ ?>