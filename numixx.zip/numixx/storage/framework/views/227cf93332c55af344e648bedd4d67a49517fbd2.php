<script>
    $(function(){

    });
</script><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Administracion/Rango/RCondici/js/tabla.blade.php ENDPATH**/ ?>