
<?php $__env->startComponent('layouts.components.pestanias.pestanias',['todoxxxx'=>$todoxxxx]); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH D:\Instalados\wamp64\www\numixx\resources\views/Pacientes/pestanias.blade.php ENDPATH**/ ?>