<div class="card">
  <div class="card-header p-2">
    <ul class="nav nav-tabs">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['excel-leer', 'excel-crear', 'excel-editar', 'excel-borrar'])): ?>
      <li class="nav-item"><a class="nav-link<?php echo e(($todoxxxx['slotxxxx']=='excel') ?' active' : ''); ?> 
        text-sm" href="<?php echo e(route('excel', $todoxxxx['padrexxx'])); ?>">Excel</a></li>
      <?php endif; ?>     
    </ul>
  </div>
  <div class="card-body">
    <div class="tab-content">
      <div class="tab-pane active" id="<?php echo e($todoxxxx['slotxxxx']); ?>">
        <?php if(isset($excel)): ?>
        <?php echo e($excel); ?>

        <?php endif; ?>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Administracion/Excel/tabsxxxx/tabsxxxx.blade.php ENDPATH**/ ?>