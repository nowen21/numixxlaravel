<div class="card">
  <div class="card-header">
    PACIENTE: <?php echo e($todoxxxx['paciente']->nombres); ?>

  </div>
  <div class="card-header p-2">
    <ul class="nav nav-tabs">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['paciente-leer', 'paciente-crear', 'paciente-editar', 'paciente-borrar'])): ?>
      <li class="nav-item"><a class="nav-link<?php echo e(($todoxxxx['slotxxxx']=='paciente') ?' active' : ''); ?> text-sm" href="<?php echo e(route('paciente.editar', $todoxxxx['parametr'])); ?>">Paciente</a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['formular-leer', 'formular-crear', 'formular-editar', 'formular-borrar'])): ?>
      <li class="nav-item"><a class="nav-link<?php echo e(($todoxxxx['slotxxxx']=='formular') ?' active' : ''); ?> text-sm" href="<?php echo e(route('formular', $todoxxxx['parametr'])); ?>">Formulaciones</a></li>
      <?php endif; ?>
      
    </ul>
  </div>
  <div class="card-body">
    <div class="tab-content">
      <div class="tab-pane active" id="<?php echo e($todoxxxx['slotxxxx']); ?>">
        <?php if(isset($paciente)): ?>
          <?php echo e($paciente); ?>

        <?php endif; ?>
        <?php if(isset($formular)): ?>
          <?php echo e($formular); ?>

        <?php endif; ?>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Pacientes/tabsxxxx/tabsxxxx.blade.php ENDPATH**/ ?>