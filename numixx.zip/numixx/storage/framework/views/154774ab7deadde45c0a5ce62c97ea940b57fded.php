<script>
  $(function(){
    $('.select2').select2({
      language: "es"
    });
    $("#servicio").keyup(function () {
      $(this).val($(this).val().toUpperCase())
    });
  });
</script><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Administracion/Servicio/Servicio/js/js.blade.php ENDPATH**/ ?>