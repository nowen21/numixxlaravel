<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        
        <?php echo $__env->make($todoxxxx["rutacarp"].'tabsxxxx.tabsxxxx', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?><?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Sistema/Rol/tabsxxxx/index.blade.php ENDPATH**/ ?>