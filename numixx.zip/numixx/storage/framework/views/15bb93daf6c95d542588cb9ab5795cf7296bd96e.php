

<?php $__currentLoopData = $todoxxxx['formular']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formulax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $idxxxxxx = '';
    $ocultarx = '';
    if ($formulax['campo_id'] == 'multiuno') {
      $idxxxxxx = 'ocultarx';
      $ocultarx = 'display: none';
    }
    $readonl = '';
    if ($formulax['campo_id'] == 'aguaeste') {
      $readonl = 'readonly';
    }
    ?>
    <tr id="<?php echo e($idxxxxxx); ?>" style="">
        <td><?php echo e($formulax['casaxxxx']); ?></td>
        <td><?php echo e(Form::select($formulax['campo_id'], $formulax['selelist'], $formulax['selevalu'],['class'=>'form-control medicamento select2','id'=>$formulax['campo_id']])); ?>

        </td>
        <td id="<?php echo e($formulax['campo_id'].'_unid'); ?>"><?php echo e($formulax['unidmedi']); ?></td>
        <td> <?php echo e(Form::text($formulax['campo_id'].'_cant', 
        $formulax['requerim'],
        ['class'=>'form-control input-number test',
        'id'=>$formulax['campo_id'].'_cant',
        'placeholder'=>'Diario',
        'onkeypress'=>'return filterFloat(event,this);',
        'data-toggle'=>"popover",
        
        $readonl,

        ])); ?> </td>
                    <td><?php echo e(Form::text($formulax['campo_id'].'_volu', 
        $formulax['volumenx'],
        ['class'=>'form-control input-number test','style'=>'width: 100px',
        'id'=>$formulax['campo_id'].'_volu',
        'onkeypress'=>'return filterFloat(event,this);',
        $readonl
        ])); ?> </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\programasinstalados\wamp64\www\numixx\resources\views/Pacientes/Cformula/formulario/adulto.blade.php ENDPATH**/ ?>