<?php
$dataxxxx = [
    'dataxxxx' => [
        [
            'name' => '_token',
            'value' => 'IRBlOEmUgE14Cp7kt8RH0YHpn6qyi2pMAlZP7MWk'
        ],
        [
            'name' => 'sis_clinica_id',
            'value' => '1'
        ],
        [
            'name' => 'tiempo',
            'value' => '24'
        ],
        [
            'name' => 'velocidad',
            'value' => '64.7'
        ],
        [
            'name' => 'volumen',
            'value' => '1553'
        ],
        [
            'name' => 'purga',
            'value' => '30'
        ],
        [
            'name' => 'peso',
            'value' => '1.5'
        ],
        [
            'name' => 'aminoaci',
            'value' => '2'
        ],
        [
            'name' => 'aminoaci_cant',
            'value' => '1.4'
        ],
        [
            'name' => 'aminoaci_volu',
            'value' => '637.8'
        ],
        [
            'name' => 'fosfatox',
            'value' => '6'
        ],

        [
            'name' => 'fosfatox_cant',
            'value' => '11'
        ],

        [
            'name' => 'fosfatox_volu',
            'value' => '4.2'
        ],
        [
            'name' => 'carbohid',
            'value' => '8'
        ],
        [
            'name' => 'carbohid_cant',
            'value' => '1.7'
        ],
        [
            'name' => 'carbohid_volu',
            'value' => '1,664.6'
        ],
        [
            'name' => 'sodioxxx',
            'value' => '10'
        ],
        [
            'name' => 'sodioxxx_cant',
            'value' => ''
        ],
        [
            'name' => 'sodioxxx_volu',
            'value' => ''
        ],
        [
            'name' => 'potasiox',
            'value' => '11'
        ],
        [
            'name' => 'potasiox_cant',
            'value' => '0.7'
        ],
        [
            'name' => 'potasiox_volu',
            'value' => ''
        ],
        [
            'name' => 'calcioxxx',
            'value' => ''
        ],
        [
            'name' => 'calcioxxx_cant',
            'value' => ''
        ],

        [
            'name' => 'calcioxxx_volu',
            'value' => ''
        ],
        [
            'name' => 'magnesio',
            'value' => ''
        ],
        [
            'name' => 'magnesio_cant',
            'value' => ''
        ],
        [
            'name' => 'magnesio_volu',
            'value' => ''
        ],
        [
            'name' => 'elemtraz',
            'value' => '17'
        ],
        [
            'name' => 'elemtraz_cant',
            'value' => ''
        ],
        [
            'name' => 'elemtraz_volu',
            'value' => ''
        ],
        [
            'name' => 'multivit',
            'value' => '20'
        ],
        [
            'name' => 'multivit_cant',
            'value' => '0.99'
        ],
        [
            'name' => 'multivit_volu',
            'value' => ''
        ],
        [
            'name' => 'glutamin',
            'value' => '4'
        ],
        [
            'name' => 'glutamin_cant',
            'value' => ''
        ],
        [
            'name' => 'glutamin_volu',
            'value' => ''
        ],
        [
            'name' => 'vitaminc',
            'value' => '21'
        ],
        [
            'name' => 'vitaminc_cant',
            'value' => ''
        ],
        [
            'name' => 'vitaminc_volu',
            'value' => ''
        ],
        [
            'name' => 'complejb',
            'value' => '22'
        ],
        [
            'name' => 'complejb_cant',
            'value' => ''
        ],
        [
            'name' => 'complejb_volu',
            'value' => ''
        ],
        [
            'name' => 'tiaminax',
            'value' => '23'
        ],
        [
            'name' => 'tiaminax_cant',
            'value' => ''
        ],
        [
            'name' => 'tiaminax_volu',
            'value' => ''
        ],
        [
            'name' => 'acidfoli',
            'value' => '24'
        ],
        [
            'name' => 'acidfoli_cant',
            'value' => ''
        ],
        [
            'name' => 'acidfoli_volu',
            'value' => ''
        ],
        [
            'name' => 'vitamink',
            'value' => '25'
        ],
        [
            'name' => 'vitamink_cant',
            'value' => ''
        ],
        [
            'name' => 'vitamink_volu',
            'value' => ''
        ],
        [
            'name' => 'lipidosx',
            'value' => '26'
        ],
        [
            'name' => 'lipidosx_cant',
            'value' => '0.5'
        ],
        [
            'name' => 'lipidosx_volu',
            'value' => ''
        ],
        [
            'name' => 'multiuno',
            'value' => '19'
        ],
        [
            'name' => 'multiuno_cant',
            'value' => ''
        ],
        [
            'name' => 'multiuno_volu',
            'value' => ''
        ],
        [
            'name' => 'npt_id',
            'value' => '1'
        ],
    ],
    'campo_id' => 'fosfatox_cant'
];

