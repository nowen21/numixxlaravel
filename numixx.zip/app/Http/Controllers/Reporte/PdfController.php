<?php

namespace App\Http\Controllers\Reporte;
use App\Http\Controllers\Controller;


use App\Traits\Pdfs\PdfTrait;

class PdfController extends Controller
{
    use PdfTrait;
}
