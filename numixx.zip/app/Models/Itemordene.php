<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Itemordene extends Model
{
    protected $fillable = [
        'itemxxxx',
        'rowspanx',
        'colspanx',
        'campoxxx',
        'aplicaxx',
        'sis_esta_id',
        'user_crea_id',
        'user_edita_id'
     ];
}
