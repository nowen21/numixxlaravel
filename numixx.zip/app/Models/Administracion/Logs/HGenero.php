<?php

namespace App\Models\Administracion\Logs;

use Illuminate\Database\Eloquent\Model;

class HGenero extends Model {

  protected $fillable = [
      'nombre',       'user_edita_id', 'user_crea_id',  'id_old',
      'sis_esta_id',
      'rutaxxxx',
      'metodoxx',
      'ipxxxxxx',
  ];




}
