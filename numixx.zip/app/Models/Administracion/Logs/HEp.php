<?php

namespace App\Models\Administracion\Logs;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class HEp extends Model {

  protected $fillable = [
       'nombre',       'user_edita_id', 'user_crea_id',  'id_old',
       'sis_esta_id',
       'rutaxxxx',
       'metodoxx',
       'ipxxxxxx',
  ];




}
