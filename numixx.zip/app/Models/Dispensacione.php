<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Dispensacione extends Model {

  protected $fillable = [
      'fechaxxx',
      'opxxxxxx',
      'estado_id',
      'producto',
  ];

}
