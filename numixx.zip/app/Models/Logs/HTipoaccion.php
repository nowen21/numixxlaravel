<?php

namespace App\Models\Logs;

use Illuminate\Database\Eloquent\Model;

class HTipoaccion extends Model {
    protected $fillable = [
        'tituloxx',
        'permisox',
        'iconoxxx',
        'pestania',
        'routexxx',
        'titulink',
        'cuerpoxx',
        'user_edita_id', 'user_crea_id',  'id_old',
        'sis_esta_id',
        'rutaxxxx',
        'metodoxx',
        'ipxxxxxx',
    ];


}
