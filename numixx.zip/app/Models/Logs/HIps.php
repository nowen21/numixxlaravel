<?php

namespace App\Models\Logs;

use Illuminate\Database\Eloquent\Model;

class HIps extends Model
{
    //
}
