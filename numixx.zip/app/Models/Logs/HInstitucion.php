<?php

namespace App\Models\Logs;

use Illuminate\Database\Eloquent\Model;

class HInstitucion extends Model
{
    //
}
