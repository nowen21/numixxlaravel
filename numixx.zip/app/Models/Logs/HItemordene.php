<?php

namespace App\Models\Logs;

use Illuminate\Database\Eloquent\Model;

class HItemordene extends Model
{
    protected $fillable = [
        'itemxxxx',
        'rowspanx',
        'colspanx',
        'campoxxx',
        'aplicaxx',
        'user_edita_id', 'user_crea_id',  'id_old',
        'sis_esta_id',
        'rutaxxxx',
        'metodoxx',
        'ipxxxxxx',
     ];
}
