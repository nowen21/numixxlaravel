<?php

namespace App\Models\Medicamentos\Unidad\Logs;

use Illuminate\Database\Eloquent\Model;

class HUnidad extends Model
{
    protected $fillable = [
        's_unidad', 
        'id_old',
        'sis_esta_id', 
        'user_crea_id', 
        'user_edita_id',
        'deleted_at',
        'rutaxxxx',
        'metodoxx',
        'ipxxxxxx',
    ];
}
