<?php

namespace App\Models\Usuarios\Logs;

use Illuminate\Database\Eloquent\Model;

class HModelHasRole extends Model
{
    //
}
