<?php

namespace App\Models\Usuarios;

use Illuminate\Database\Eloquent\Model;

class ModelHasRole extends Model
{
    //
}
