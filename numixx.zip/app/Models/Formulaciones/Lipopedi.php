<?php

namespace App\Models\Formulaciones;

use Illuminate\Database\Eloquent\Model;

class Lipopedi extends Model
{
    //
}
