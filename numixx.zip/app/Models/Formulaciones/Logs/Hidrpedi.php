<?php

namespace App\Models\Formulaciones\Logs;

use Illuminate\Database\Eloquent\Model;

class Hidrpedi extends Model
{
    //
}
