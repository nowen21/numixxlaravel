<?php

namespace App\Models\Formulaciones\Logs;

use Illuminate\Database\Eloquent\Model;

class Lipopedi extends Model
{
    //
}
