<a class="btn btn-sm btn-primary" href="{{ route('usuarios.editar', $id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('usuarios.ver', $id) }}">Ver</a>