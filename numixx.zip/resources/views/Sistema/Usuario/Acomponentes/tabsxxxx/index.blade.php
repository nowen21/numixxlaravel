<section class="content">
    <div class="container-fluid">
        <div class="row">
            @include($todoxxxx["rutacarp"].'Acomponentes.tabsxxxx.'.$todoxxxx["perfilxx"])
        </div>
    </div>
</section>
@endsection
