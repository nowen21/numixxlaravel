<button class="btn btn-sm btn-danger"  id="{{$queryxxx->id}}"type="button" >Inctivar</button>
