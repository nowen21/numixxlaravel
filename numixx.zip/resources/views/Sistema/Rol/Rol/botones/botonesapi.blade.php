<a class="btn btn-sm btn-primary" href="{{ route('roles.editar', $id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('roles.ver', $id) }}">Ver</a>