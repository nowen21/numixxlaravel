<div class="form-group row">
    <div class="form-group col-md-12" style="color: red; text-align: center; font-size: 40px;">
    ¿DESEA INACTIVAR LA CLINICA: {{$todoxxxx['modeloxx']->clinica}}..?
    </div>
</div>
