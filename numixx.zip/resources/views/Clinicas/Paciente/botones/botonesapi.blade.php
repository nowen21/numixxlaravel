<a class="btn btn-sm btn-primary" href="{{ route('paciente.editar', [$sis_clinica_id,$id]) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('paciente.ver', [$sis_clinica_id,$id]) }}">Ver</a>
<a class="btn btn-sm btn-primary" href="{{ route('formular.nuevo', [$sis_clinica_id,$id]) }}">Formular</a>