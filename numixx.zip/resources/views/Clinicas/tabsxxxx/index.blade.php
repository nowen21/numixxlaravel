<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        {{-- ventanas --}}

        @include($todoxxxx["rutacarp"].'tabsxxxx.tabsxxxx')
        {{-- ventanas --}}
      </div>
    </div>
  </div>
</section>

@endsection
