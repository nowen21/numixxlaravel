<div class="card-body">
    <div class="tab-content">
        <div class="tab-pane active" id="{{ $todoxxxx['slotxxxx'] }}">
            @if(isset($clinica))
            {{ $clinica }}
            @endif
            @if(isset($cmedicame))
            {{ $cmedicame }}
            @endif
            @if(isset($crango))
            {{ $crango }}
            @endif
            @if(isset($cremision))
            {{ $cremision }}
            @endif
        </div>
    </div>
</div>