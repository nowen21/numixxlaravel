<div class="card-body">
    <div class="tab-content">
        <div class="tab-pane active" id="{{ $todoxxxx['slotxxxx'] }}">
        @if(isset($paciente))
          {{ $paciente }}
        @endif
        @if(isset($formular))
          {{ $formular }}
        @endif
        </div>
    </div>
</div>