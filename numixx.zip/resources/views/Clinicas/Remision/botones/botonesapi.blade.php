<a class="btn btn-sm btn-primary" href="{{ route('clinica.editar', $id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('clinica.ver', $id) }}">Ver</a>