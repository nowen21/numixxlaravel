<a class="btn btn-sm btn-primary " href="{{ route($requestx->routexxx[0].'.ver', $queryxxx->id) }}">Ver</a>
<a class="btn btn-sm btn-primary " href="{{ route($requestx->routexxx[0].'.editar', $queryxxx->id) }}">Editar</a>
<a class="btn btn-sm btn-primary " target="_blank" href="{{ route($requestx->routexxx[0].'.imprimir', $queryxxx->id) }}">Imprimir</a>



