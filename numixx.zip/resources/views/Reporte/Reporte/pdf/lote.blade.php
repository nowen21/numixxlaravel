<table style=" width: 100%;" cellspacing='0' >
  <tr>
    <td style="width: 15%; text-align: left; height: 75px;border: 1px #000 solid " rowspan="2" >
      <img src="{{ url('img/Numixx_Nuevo_Logo.png') }}"   style="width: 135px; height: 76px;" alt="logo">
    </td>
    <td style=" width: 70%; text-align: center;border: 1px #000 solid  " colspan="2" rowspan="2">CERTIFICADO DE LIBERACIÓN DE LOTE</td>

    <td style=" width: 15%; text-align: left; border: 1px #000 solid">CÓDIGO</td>
  </tr>
  <tr>     
    <td style="  text-align: left; border: 1px #000 solid">PRO-FO-13-V0</td>
  </tr>

</table>
<table style=" width: 100%;"  cellspacing='0'>
  <tr >
    <td style="text-align: center;height: 30px;border: 1px #000 solid" >
      La Dirección Técnica certifica que el producto
    </td>
  </tr>
  <tr>
    <td style=" text-align: left; text-align: center;border: 1px #000 solid" >
      NUTRICIÓN PARENTERAL
    </td>
   </tr>

</table>
<style>
  .verticalText {
    writing-mode: vertical-lr;
    transform: rotate(270deg);
  }
</style>
<table style="width: 100%; padding-top: 25px;padding-bottom: 25px" cellspacing='0'>
  <td style=" border: 1px #000 solid">
    <div style=" text-align: left; text-align: center">
      Lote(S): <u> {{$menor}} </u>  Vence: <u> {{ $vencimiento}} </u> 
    </div>
    <br>
    <div style=" text-align: left; text-align: center">
      Queda liberada para la entrega al cliente, puesto que toda la documentación inherente a la elaboración y/o ajuste y análisis fue revisada según el formato 
      de controles en proceso y este indica que el (los) producto(s) fue manufacturado en cumplimiento con los requerimientos de las Buenas Prácticas de 
      Elaboración según la normativa vigente. test test test
    </div>
      <br>
      <div style=" text-align: left; text-align: center">Revisión realizada por: <u> {{$userx}} </u> en fecha:  <u> {{$hoyxx}} </u> </div>
      <br>
  </td>
</table>
<table style="width: 100%; padding-bottom: 1px" cellspacing='0'>
  <tr>
    <th style="width: 10%;height: 40px; border: 1px #000 solid">Observaciones</th>
    <td style=" border: 1px #000 solid"></td>
  </tr>
</table>
