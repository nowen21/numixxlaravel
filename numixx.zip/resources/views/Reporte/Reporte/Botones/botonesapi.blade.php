


<a class="btn btn-sm btn-primary " href="{{ route($requestx->routexxx[0].'.imprimir', $queryxxx->id) }}">Imprimir</a>
<a class="btn btn-sm btn-primary " href="{{ route('reporpdf.etiquetanpt', $queryxxx->cformula->id) }}">Etiqueta</a>

