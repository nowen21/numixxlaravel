
<a class="btn btn-sm btn-primary " href="{{ route('reporpdf.dloteimp', $queryxxx->id) }}">Imprimir</a>

