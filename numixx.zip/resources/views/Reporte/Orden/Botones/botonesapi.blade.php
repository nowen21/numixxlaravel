<a class="btn btn-sm btn-primary" href="{{ route('paciente.editar', $id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('paciente.ver', $id) }}">Ver</a>