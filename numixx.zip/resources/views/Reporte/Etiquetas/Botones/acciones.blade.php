<a class="btn btn-sm btn-primary " target="_blank" href="{{ route($requestx->routexxx[0].'.imprimir', $queryxxx->id) }}">Imprimir</a>
