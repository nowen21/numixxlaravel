@extends('errors::layout')

@section('title', 'Acceso Restingido')
@section('message', 'Acceso restringido a este recurso!.')