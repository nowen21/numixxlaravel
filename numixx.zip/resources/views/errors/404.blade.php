@extends('errors::layout')

@section('title', 'No encontrado')
@section('message', 'El recurso solicitado no se encuentra!.')