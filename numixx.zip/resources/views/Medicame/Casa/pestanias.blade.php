
@component('layouts.components.pestanias.pestaniasgeneral',['todoxxxx'=>$todoxxxx])
@endcomponent

