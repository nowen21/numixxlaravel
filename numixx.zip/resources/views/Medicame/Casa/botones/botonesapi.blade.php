<a class="btn btn-sm btn-primary" href="{{ route('casa.editar', $id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('casa.ver', $id) }}">Ver</a>