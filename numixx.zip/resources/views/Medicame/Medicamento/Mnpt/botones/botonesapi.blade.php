<a class="btn btn-sm btn-primary" href="{{ route('mnpt.editar', [$medicame_id,$id]) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('mnpt.ver', [$medicame_id,$id]) }}">Ver</a>
