<a class="btn btn-sm btn-primary" href="{{ route('medicamento.editar', $id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('medicamento.ver', $id) }}">Ver</a>