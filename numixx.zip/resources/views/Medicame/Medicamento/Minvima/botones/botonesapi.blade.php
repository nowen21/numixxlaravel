<a class="btn btn-sm btn-primary" href="{{ route('minvima.editar', [$medicame_id,$id]) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('minvima.ver', [$medicame_id,$id]) }}">Ver</a>