@extends('layouts.index')
@section('content')
  <div class="jumbotron text-center">
  <h1 class="display-4">NUMIXX</h1>
  <p class="lead">FORMULACIONES</p>
  <hr class="my-4">
  <p>Sistema de Formulaciones</p>
</div>
@endsection