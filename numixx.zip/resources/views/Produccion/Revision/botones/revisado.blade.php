<div class="text-center" style="width: 100%">
<span class="fas fa-{{$queryxxx->userevis_id==''?'times':'check'}} text-{{$queryxxx->userevis_id==''?'danger':'success'}}" aria-hidden="true"></span>
</div>
