

<a class="btn btn-sm btn-primary " href="{{ route($requestx->routexxx[0].'.imprimir', $queryxxx->id) }}">Imprimir</a>

