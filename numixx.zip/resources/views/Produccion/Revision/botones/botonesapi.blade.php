<a class="btn btn-sm btn-primary" href="{{ route('revision.editar', [$queryxxx->id]) }}">Revisar Formulación</a>
<a class="btn btn-sm btn-primary" href="{{ route('reporpdf.etiquetanpt', [$queryxxx->id]) }}">Imprimir Etiqueta</a>
