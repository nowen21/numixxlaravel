<div class="text-center" style="width: 100%">
<span class="fas fa-{{$queryxxx->terminado_id==''?'times':'check'}} text-{{$queryxxx->terminado_id==''?'danger':'success'}}" aria-hidden="true"></span>
</div>
