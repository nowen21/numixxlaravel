<a class="btn btn-sm btn-primary" href="{{ route('preparac.editar', $id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('preparac.ver', $id) }}">Ver</a>