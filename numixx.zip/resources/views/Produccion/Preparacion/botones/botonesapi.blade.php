<a class="btn btn-sm btn-primary" href="{{ route('preparac.editar', $queryxxx->id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('preparac.ver', $queryxxx->id) }}">Ver</a>