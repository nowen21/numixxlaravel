<div class="text-center" style="width: 100%">
<span class="fas fa-{{$queryxxx->userprep_id==''?'times':'check'}} text-{{$queryxxx->userprep_id==''?'danger':'success'}}" aria-hidden="true"></span>
</div>
