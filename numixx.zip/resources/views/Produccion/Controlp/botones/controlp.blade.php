<div class="text-center" style="width: 100%">
<span class="fas fa-{{$queryxxx->proceso_id ==''?'times':'check'}} text-{{$queryxxx->proceso_id  ==''?'danger':'success'}}" aria-hidden="true"></span>
</div>
