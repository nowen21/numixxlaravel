
@component($todoxxxx["rutacarp"].'Acomponentes.Acrud.pestanias',['todoxxxx'=>$todoxxxx])

@endcomponent

