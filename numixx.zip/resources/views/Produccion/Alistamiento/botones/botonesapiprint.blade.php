




<a class="btn btn-sm btn-primary" href="{{ route('alistami.imprimir',$queryxxx->id) }}">Imprimir</a>

