<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-9">
        {{-- ventanas --}}
        @include($todoxxxx['tabsxxxx'].'.tabs')
        {{-- ventanas --}}
      </div>
	  <div class="col-md-3">
        {{--  Info Basica --}}
        @include($todoxxxx['cardxxxx'].'.infoBase')
	  </div>
    </div>
  </div>
</section>

@endsection