<a class="btn btn-sm btn-primary" href="{{ route('fossubtipo.editar', $id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('fossubtipo.ver', $id) }}">Ver</a>