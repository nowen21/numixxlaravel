<li class="nav-item has-treeview">
    <a href="#" class="nav-link">
        <i class="nav-icon fas fa-clipboard-check"></i>
        <p>
            Producción
            <i class="fas fa-angle-left right"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="{{ route('produccion') }}" class="nav-link">
                <i class="fas fa-child nav-icon"></i>
                <p>Producción</p>
            </a>
        </li>

    </ul>
</li>