<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <!-- Left navbar links -->
  @include('layouts.nav-bar.left.index')
  <!-- End Left navbar links -->

  <!-- Search Form -->
  {{-- @include('layouts.nav-bar.search') --}}
  <!-- End Search Form -->

  <!-- Right navbar links -->
  @include('layouts.nav-bar.right.index')
  <!-- End Right navbar links -->
</nav>