<div class="media">
  <img src="{{ asset('adminlte/dist/img/user1-128x128.jpg/') }}  " alt="User Avatar"
    class="img-size-50 mr-3 img-circle">
  <div class="media-body">
    <h3 class="dropdown-item-title">
      Jose Dumar
      <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
    </h3>
    <p class="text-sm">Iniciamos el desarrollo...</p>
    <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i>Hace 4 horas </p>
  </div>
</div>
