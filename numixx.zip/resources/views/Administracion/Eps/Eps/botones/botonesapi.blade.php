<a class="btn btn-sm btn-primary" href="{{ route('eps.editar', $id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('eps.ver', $id) }}">Ver</a>