
@component('layouts.components.pestanias.pestanias',['todoxxxx'=>$todoxxxx])
@endcomponent