<a class="btn btn-sm btn-primary" href="{{ route('servicio.editar', [$id]) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('servicio.ver', [$id]) }}">Ver</a>
