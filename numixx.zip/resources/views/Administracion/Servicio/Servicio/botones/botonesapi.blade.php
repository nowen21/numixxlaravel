<a class="btn btn-sm btn-primary" href="{{ route('cservicio.editar', [$id]) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('cservicio.ver', [$id]) }}">Ver</a>