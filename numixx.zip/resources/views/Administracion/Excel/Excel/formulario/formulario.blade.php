<div class="form-group row">
    <div class="form-group col-md-12">
        <input type="file" class="custom-file-input" id="excelxxx" name="excelxxx">
        <label class="custom-file-label" for="customFile">Seleccione un archivo</label>

        
          </div>

        
    </div>
</div>