<a class="btn btn-sm btn-primary" href="{{ route('rango.editar', $id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('rango.ver', $id) }}">Ver</a>