<a class="btn btn-sm btn-primary" href="{{ route('rnpt.editar', [$rango_id,$id]) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('rnpt.ver', [$rango_id,$id]) }}">Ver</a>