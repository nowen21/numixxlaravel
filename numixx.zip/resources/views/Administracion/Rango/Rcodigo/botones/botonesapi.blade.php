<a class="btn btn-sm btn-primary" href="{{ route('rcodigo.editar', [$rango_id,$id]) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('rcodigo.ver', [$rango_id,$id]) }}">Ver</a>