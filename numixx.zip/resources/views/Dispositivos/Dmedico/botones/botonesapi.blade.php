<a class="btn btn-sm btn-primary" href="{{ route('dmedico.editar', $id) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('dmedico.ver', $id) }}">Ver</a>