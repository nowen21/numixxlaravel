<a class="btn btn-sm btn-primary" href="{{ route('dlote.editar', [$dmedico_id,$id]) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('dlote.ver', [$dmedico_id,$id]) }}">Ver</a>