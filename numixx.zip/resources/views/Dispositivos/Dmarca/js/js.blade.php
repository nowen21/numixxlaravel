<script>

  $(document).ready(function () {
   $('.select2').select2({
      language: "es",
      theme: 'bootstrap4'
    });
  });
</script>
