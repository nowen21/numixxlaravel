<a class="btn btn-sm btn-primary" href="{{ route('dmarca.editar', [$dmedico_id,$id]) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('dmarca.ver', [$dmedico_id,$id]) }}">Ver</a>