<a class="btn btn-sm btn-primary" href="{{ route('formular.editar', [$paciente_id,$id]) }}">Editar</a>
<a class="btn btn-sm btn-primary" href="{{ route('formular.ver', [$paciente_id,$id]) }}">Ver</a>