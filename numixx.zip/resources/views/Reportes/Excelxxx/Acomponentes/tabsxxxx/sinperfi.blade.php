<div class="col-md-12">
    {{-- ventanas --}}
    @include($todoxxxx["rutacarp"].'Acomponentes.tabsxxxx.tabsxxxx')
    {{-- ventanas --}}
</div>
